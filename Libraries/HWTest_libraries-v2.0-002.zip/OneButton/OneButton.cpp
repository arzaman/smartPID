// -----
// OneButton.cpp - Library for detecting button clicks, doubleclicks and long press pattern on a single button.
// This class is implemented for use with the Arduino environment.
// Copyright (c) by Matthias Hertel, http://www.mathertel.de
// This work is licensed under a BSD style license. See http://www.mathertel.de/License.aspx
// More information on: http://www.mathertel.de/Arduino
// -----
// Changelog: see OneButton.h
// -----

#include "OneButton.h"

extern void ButtonBeep(void);
// ----- Initialization and Default Values -----

mOneButton::mOneButton(int pin, volatile TButton_status *b_status, int normal_level)
{
  bstatus=b_status;
  pinMode(pin, INPUT_PULLUP/*INPUT*/);      // sets the MenuPin as input
  _pin = pin;

  _clickTicks = 150/*600*/;        // number of millisec that have to pass by before a click is detected.
  _pressTicks = 1000/*1000*/;       // number of millisec that have to pass by before a long button press is detected.

  _state = 0; // starting with state 0: waiting for button to be pressed
  _isLongPressed = false;  // Keep track of long press state

  if (normal_level) {
	// button connects ground to the pin when pressed.
	_buttonReleased = HIGH; // notPressed
	_buttonPressed = LOW;
//    digitalWrite(pin, HIGH);   // turn on pullUp resistor

  } else {
	// button connects VCC to the pin when pressed.
	_buttonReleased = LOW;
	_buttonPressed = HIGH;
  } // if

/*
  _doubleClickFunc = NULL;
  _pressFunc = NULL;
  _longPressStartFunc = NULL;
  _longPressStopFunc = NULL;
  _duringLongPressFunc = NULL;
*/
} // OneButton


// explicitly set the number of millisec that have to pass by before a click is detected.
void mOneButton::setClickTicks(int ticks) {
  _clickTicks = ticks;
} // setClickTicks


// explicitly set the number of millisec that have to pass by before a long button press is detected.
void mOneButton::setPressTicks(int ticks) {
  _pressTicks = ticks;
} // setPressTicks

/*
// save function for click event
void mOneButton::attachClick(callbackFunction newFunction)
{
  _clickFunc = newFunction;
} // attachClick


// save function for doubleClick event
void mOneButton::attachDoubleClick(callbackFunction newFunction)
{
  _doubleClickFunc = newFunction;
} // attachDoubleClick


// save function for press event
// DEPRECATED, is replaced by attachLongPressStart, attachLongPressStop, attachDuringLongPress,
void mOneButton::attachPress(callbackFunction newFunction)
{
  _pressFunc = newFunction;
} // attachPress

// save function for longPressStart event
void mOneButton::attachLongPressStart(callbackFunction newFunction)
{
  _longPressStartFunc = newFunction;
} // attachLongPressStart

// save function for longPressStop event
void mOneButton::attachLongPressStop(callbackFunction newFunction)
{
  _longPressStopFunc = newFunction;
} // attachLongPressStop

// save function for during longPress event
void mOneButton::attachDuringLongPress(callbackFunction newFunction)
{
  _duringLongPressFunc = newFunction;
} // attachDuringLongPress
*/
// function to get the current long pressed state
bool mOneButton::isLongPressed(){
  return _isLongPressed;
}

void mOneButton::tick(void)
{
  // Detect the input information
  int buttonLevel = digitalRead(_pin); // current button signal.
  unsigned long now = millis(); // current (relative) time in msecs.

  bstatus->status.level=buttonLevel;
  // Implementation of the state machine
  if (_state == 0) { // waiting for menu pin being pressed.
	if (buttonLevel == _buttonPressed) {
	  _state = 1; // step to state 1
	  _startTime = now; // remember starting time
	  bstatus->status.trig_press=0;
	  autorepeat_count=0;
      bstatus->status.autorepeat_factor=1;
	  //    bstatus->status.press=1;//????
	} // if

  }
  else if (_state == 1) { // waiting for menu pin being released.

	if ((buttonLevel == _buttonReleased) && ((unsigned long)(now - _startTime) < _debounceTicks)) {
	  // button was released to quickly so I assume some debouncing.
	  // go back to state 0 without calling a function.
	  bstatus->status.trig_press=0;
	  _state = 0;

	} else if (buttonLevel == _buttonReleased) {
	  bstatus->status.trig_press=0;
	  _state = 2; // step to state 2

	} else if ((buttonLevel == _buttonPressed) && ((unsigned long)(now - _startTime) > _pressTicks)) {
	  _isLongPressed = true;  // Keep track of long press state
//	  /*if (_pressFunc)*/ bstatus->status.press=1; //_pressFunc();
	  /*if (_longPressStartFunc)*/ bstatus->status.long_start=1;//_longPressStartFunc();
	  /*if (_duringLongPressFunc)*/ bstatus->status.long_press=1;//_duringLongPressFunc();
	  _state = 6; // step to state 6

	} else if((buttonLevel == _buttonPressed) && ((unsigned long)(now - _startTime) >= _debounceTicks)){
		if(bstatus->status.trig_press==0)
		{
		bstatus->status.trig_press=1;
		bstatus->status.press=1;
        ButtonBeep();
		}
	  // wait. Stay in this state.
	} // if


  }
  else if (_state == 2) { // waiting for menu pin being pressed the second time or timeout.
	if ((unsigned long)(now - _startTime) > _clickTicks) {
	  // this was only a single short click
	  /*if (_clickFunc)*/ bstatus->status.click=1;//_clickFunc();
	  _state = 0; // restart.

	} else if (buttonLevel == _buttonPressed) {
	  _state = 3; // step to state 3
	} // if

  } else if (_state == 3) { // waiting for menu pin being released finally.
	if (buttonLevel == _buttonReleased) {
	  // this was a 2 click sequence.
	  bstatus->status.trig_press=0;
	  /*if (_doubleClickFunc)*/ bstatus->status.duble_click=1;//_doubleClickFunc();
	  _state = 0; // restart.
	} // if

  } else if (_state == 6) { // waiting for menu pin being release after long press.
	if (buttonLevel == _buttonReleased) {
	  bstatus->status.trig_press=0;
	  _isLongPressed = false;  // Keep track of long press state
	  bstatus->status.long_stop=1;//_longPressStopFunc();

    bstatus->status.press=0;
    bstatus->status.click=0;
    bstatus->status.autorepeat=0;
    bstatus->status.duble_click=0;
    bstatus->status.long_start=0;
    bstatus->status.long_press=0;
      
	  _state = 0; // restart.
	} else {
	  // button is being long pressed
	  _isLongPressed = true; // Keep track of long press state
	  /*if (_duringLongPressFunc)*/ bstatus->status.long_press=1;//_duringLongPressFunc();
	  if((++autorepeat_tick_count)>freq_repeat_key) {
		autorepeat_count++;
		if(autorepeat_count>=70) bstatus->status.autorepeat_factor=500;
		else if (autorepeat_count>=60) bstatus->status.autorepeat_factor=100;
		else if (autorepeat_count>=40) bstatus->status.autorepeat_factor=50;
		else if (autorepeat_count>=30) bstatus->status.autorepeat_factor=20;
		else if (autorepeat_count>=10) bstatus->status.autorepeat_factor=5;
		bstatus->status.autorepeat=1; autorepeat_tick_count=0;
		ButtonBeep();
      }
	} // if

  } // if
} // OneButton.tick()


// end.

