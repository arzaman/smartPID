/*
 * Asynchronous network client interface
 *
 *  Copyright (C) 2016 Arzaman
 */

#ifndef ASYNC_CLIENT_H_
#define ASYNC_CLIENT_H_

#include <Client.h>

/* Asynchronous network client: extends the Client class to provide non-blocking
 * methods. */
class AsyncClient : public Client {
public:

	/* Initiate a TCP connection to a remote server
	 * The result of the connection attempt can later be retrieved by calling
	 * the connectedAsync() method
	 * Parameters:
	 * - host: server URL
	 * - port: server TCP port to connect to
	 * Returns: 0 if connection has been initiated, negative return code
	 *   otherwise
	 */
	virtual int connectAsync(const char *host, uint16_t port) = 0;

	/* Initiate a TCP connection to a remote server
	 * The result of the connection attempt can later be retrieved by calling
	 * the connectedAsync() method
	 * Parameters:
	 * - host: server IP address
	 * - port: server TCP port to connect to
	 * Returns: 0 if connection has been initiated, negative return code
	 *   otherwise
	 */
	virtual int connectAsync(IPAddress ip, uint16_t port) = 0;

	/* Checks whether a TCP connection initiation triggered by a call to
	 * connectAsync() succeded
	 * This method returns immediately and can be called from interrupt context
	 * Parameters: none
	 * Returns: positive value if connection was established, negative value if
	 *          connection could not be established, zero if connection attempt
	 *          is still in progress
	 */
	virtual int connectedAsync() = 0;

	/* Checks whether a connection between a client and a server is in place
	 * If the update argument is false, this method returns immediately and can
	 * be called from interrupt context, but may not give up-to-date results.
	 * If the update argument is true, calling this method is equivalent to
	 * calling the connected() method.
	 * Parameters:
	 * - update: if true, the network module is queried for an updated status,
	 *           otherwise a cached status is returned
	 * Returns: non-zero value if connection is in place, zero otherwise
	 */
	virtual int connStatus(bool update = false) = 0;

	/* Send asynchronously data to a remote host
	 * This method returns immediately and can be called from interrupt context;
	 * data transmission results can later be checked by calling the checkSent()
	 * method until it returns a non-zero code (meaning that transmission
	 * results are available)
	 * Parameters: buf: buffer containing data to be sent
	 *             len: length of data to be sent
	 * Returns: 0 if data has been correctly queued for transmission, error code
	 *          from Client::write() otherwise
	 */
	virtual int sendAsync(uint8_t *buf, unsigned int len) = 0;

	/* Check the status of data transmission initiated by sendAsync()
	 * This method returns immediately and can be called from interrupt context
	 * Parameters: none
	 * Returns: 0 if data transmission results are not available yet, return
	 *          code from Client::write() otherwise
	 */
	virtual size_t checkSent() = 0;

	/* Shut down asynchronously TCP connection with remote host
	 * The connection status can later be retrieved by calling the
	 * stoppedAsync() method
	 * Parameters: none
	 * Returns: 0 if disconnection has been initiated, negative return code
	 *   otherwise
	 */
	virtual int stopAsync() = 0;

	/* Checks whether a TCP connection to a remote server has been shut down
	 * This method is called to check whether a disconnection initiated with
	 * stopAsync() has been completed.
	 * Parameters: none
	 * Returns: true if connection has been shut down, false otherwise
	 */
	virtual bool stoppedAsync() = 0;
};

#endif
