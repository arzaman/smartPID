/******************************************************************************
ESP8266 UDP Server Source File
Copyright (C) 2016 Arzaman
******************************************************************************/

#include "ESP8266UdpServer.h"
#include "SparkFunESP8266WiFi.h"

ESP8266UdpServer::ESP8266UdpServer(uint16_t port)
{
    _port = port;
    _socket = ESP8266_SOCK_NOT_AVAIL;
}

void ESP8266UdpServer::begin()
{
	int16_t ret = esp8266.configureUDPServer(_port);

	if (ret > 0)
		_socket = ret;
}

bool ESP8266UdpServer::beginCheck()
{
	int16_t ret = esp8266.configureUDPServer(_port);

	if (ret < 0)
		return false;
	else {
		_socket = ret;
		return true;
	}
}

bool ESP8266UdpServer::running()
{
    return (_socket != ESP8266_SOCK_NOT_AVAIL);
}

int ESP8266UdpServer::available()
{
	int available = esp8266.availableOnSocket(_socket);

	if (available < 0)
		available = 0;
	return available;
}

int ESP8266UdpServer::read()
{
	return esp8266.readFromSocket(_socket);
}

size_t ESP8266UdpServer::write(uint8_t b)
{
    return write(&b, 1);
}

size_t ESP8266UdpServer::write(const uint8_t *buffer, size_t size)
{	
	return esp8266.tcpSend(_socket, buffer, size);
}

void ESP8266UdpServer::end()
{
	while (esp8266.close(_socket) < 0) {}
}
