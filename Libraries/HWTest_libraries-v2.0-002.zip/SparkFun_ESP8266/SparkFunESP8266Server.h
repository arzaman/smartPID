/******************************************************************************
SparkFunESP8266Server.h
ESP8266 WiFi Library Server Header File
Jim Lindblom @ SparkFun Electronics
Original Creation Date: June 20, 2015
http://github.com/sparkfun/SparkFun_ESP8266_AT_Arduino_Library

This code is beerware; if you see me (or any other SparkFun employee) at the
local, and you've found our code helpful, please buy us a round!

Distributed as-is; no warranty is given.
******************************************************************************/

#ifndef _SPARKFUNESP8266SERVER_H_
#define _SPARKFUNESP8266SERVER_H_

#include <Arduino.h>
#include <IPAddress.h>
#include "Server.h"
#include "SparkFunESP8266WiFi.h"
#include "SparkFunESP8266Client.h"

class ESP8266Server : public Server 
{
public:
	ESP8266Server(uint16_t);
	ESP8266Client available(uint8_t wait = 0);
	void begin();
	/* Initialize a TCP server and return results
	 * This method does the same as begin(), but in addition returns a result
	 * code.
	 * Parameters: none
	 * Returns: true if server can be initialized successfully, false otherwise
	 */
	bool beginCheck();
	virtual size_t write(uint8_t);
	virtual size_t write(const uint8_t *buf, size_t size);
	uint8_t status();
	/* Shut down TCP server
	 * Parameters: none
	 * Returns: none
	 */
	void end();

	using Print::write;
	
private:
	uint16_t _port;
};

#endif
