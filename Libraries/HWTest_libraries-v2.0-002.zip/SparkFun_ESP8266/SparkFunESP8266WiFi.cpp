/******************************************************************************
SparkFunESP8266WiFi.cpp
ESP8266 WiFi Library Main Source File
Jim Lindblom @ SparkFun Electronics
Original Creation Date: June 20, 2015
http://github.com/sparkfun/SparkFun_ESP8266_AT_Arduino_Library

This code is beerware; if you see me (or any other SparkFun employee) at the
local, and you've found our code helpful, please buy us a round!

Distributed as-is; no warranty is given.
******************************************************************************/

#include <SparkFunESP8266WiFi.h>
#include <Arduino.h>
#include "util/ESP8266_AT.h"
#include "SparkFunESP8266Client.h"

#define ESP8266_DISABLE_ECHO

/* Timeout, in milliseconds, after which any unsolicited indication received
 * from ESP8266 and not processed is discarded. */
#define ESP826_IND_TIMEOUT	100

#define ESP8266_CHECK_BUSY(readInd)	do {				\
	noInterrupts();										\
	if (async_busy) {									\
		interrupts();									\
		return ESP8266_CMD_BUSY;						\
	}													\
	if (ind_ongoing) {									\
		/* An indication is being received: if nobody is bothering to read it,
		 * discard it. */								\
		if (millis() - ind_time >= ESP826_IND_TIMEOUT)	\
			ind_ongoing = false;						\
														\
		if (!readInd) {									\
			interrupts();								\
			return ESP8266_CMD_BUSY;					\
		}												\
	}													\
	async_busy = true;									\
	interrupts();										\
} while (0)

////////////////////////
// Buffer Definitions //
////////////////////////
#define ESP8266_RX_BUFFER_LEN 257 // Number of bytes in the serial receive buffer
char esp8266RxBuffer[ESP8266_RX_BUFFER_LEN];
unsigned int bufferHead; // Holds position of latest byte placed in buffer.

////////////////////
// Initialization //
////////////////////

ESP8266Class::ESP8266Class()
{
	for (int i=0; i<ESP8266_MAX_SOCK_NUM; i++)
		_state[i] = AVAILABLE;
}

bool ESP8266Class::begin(Uart &uart, unsigned long baudRate)
{
	_baud = baudRate;
	uart.begin(baudRate);
	_serial = &uart;
	if (test())
	{
		//if (!setTransferMode(0))
		//	return false;
		if (!setMux(1))
			return false;
#ifdef ESP8266_DISABLE_ECHO
		if (!echo(false))
			return false;
#endif
		return true;
	}
	
	return false;
}

///////////////////////
// Basic AT Commands //
///////////////////////

bool ESP8266Class::test()
{
	sendCommand(ESP8266_TEST); // Send AT

	if (readForResponse(RESPONSE_OK, COMMAND_RESPONSE_TIMEOUT) > 0)
		return true;
	
	return false;
}

bool ESP8266Class::reset(bool wait)
{
	sendCommand(ESP8266_RESET); // Send AT+RST
	
	if (!wait)
		return true;
	if (readForResponse(RESPONSE_READY, COMMAND_RESET_TIMEOUT) > 0)
		return true;
	
	return false;
}

bool ESP8266Class::echo(bool enable)
{
	if (enable)
		sendCommand(ESP8266_ECHO_ENABLE);
	else
		sendCommand(ESP8266_ECHO_DISABLE);
	
	if (readForResponse(RESPONSE_OK, COMMAND_RESPONSE_TIMEOUT) > 0)
		return true;
	
	return false;
}

bool ESP8266Class::setBaud(unsigned long baud)
{
	char parameters[16];
	memset(parameters, 0, 16);
	// Constrain parameters:
	baud = constrain(baud, 110, 115200);
	
	// Put parameters into string
	sprintf(parameters, "%d,8,1,0,0", baud);
	
	// Send AT+UART=baud,databits,stopbits,parity,flowcontrol
	sendCommand(ESP8266_UART, ESP8266_CMD_SETUP, parameters);
	
	if (readForResponse(RESPONSE_OK, COMMAND_RESPONSE_TIMEOUT) > 0)
		return true;
	
	return false;
}

int16_t ESP8266Class::getVersion(char * ATversion, char * SDKversion)
{
	sendCommand(ESP8266_VERSION); // Send AT+GMR
	// Example Response: AT version:0.30.0.0(Jul  3 2015 19:35:49)\r\n (43 chars)
	//                   SDK version:1.2.0\r\n (19 chars)
	//                   OK\r\n
	// Look for "OK":
	int16_t rsp = (readForResponse(RESPONSE_OK, COMMAND_RESPONSE_TIMEOUT) > 0);
	if (rsp > 0)
	{
		char *p, *q;
		// Look for "AT version" in the rxBuffer
		p = strstr(esp8266RxBuffer, "AT version:");
		if (p == NULL) return ESP8266_RSP_UNKNOWN;
		p += strlen("AT version:");
		q = strchr(p, '\r'); // Look for \r
		if (q == NULL) return ESP8266_RSP_UNKNOWN;
		memcpy(ATversion, p, q - p);
		ATversion[q - p] = '\0';
		
		// Look for "SDK version:" in the rxBuffer
		p = strstr(esp8266RxBuffer, "SDK version:");
		if (p == NULL) return ESP8266_RSP_UNKNOWN;
		p += strlen("SDK version:");
		q = strchr(p, '\r'); // Look for \r
		if (q == NULL) return ESP8266_RSP_UNKNOWN;
		memcpy(SDKversion, p, q - p);
		SDKversion[q - p] = '\0';
	}
	
	return rsp;
}

////////////////////
// WiFi Functions //
////////////////////

// getMode()
// Input: None
// Output:
//    - Success: 1, 2, 3 (ESP8266_MODE_STA, ESP8266_MODE_AP, ESP8266_MODE_STAAP)
//    - Fail: <0 (esp8266_cmd_rsp)
int16_t ESP8266Class::getMode()
{
	sendCommand(ESP8266_WIFI_MODE, ESP8266_CMD_QUERY);
	
	// Example response: \r\nAT+CWMODE_CUR?\r+CWMODE_CUR:2\r\n\r\nOK\r\n
	// Look for the OK:
	int16_t rsp = readForResponse(RESPONSE_OK, COMMAND_RESPONSE_TIMEOUT);
	if (rsp > 0)
	{
		// Then get the number after ':':
		char * p = strchr(esp8266RxBuffer, ':');
		if (p != NULL)
		{
			char mode = *(p+1);
			if ((mode >= '1') && (mode <= '3'))
				return (mode - 48); // Convert ASCII to decimal
		}
		
		return ESP8266_RSP_UNKNOWN;
	}
	
	return rsp;
}

// setMode()
// Input: 1, 2, 3 (ESP8266_MODE_STA, ESP8266_MODE_AP, ESP8266_MODE_STAAP)
// Output:
//    - Success: >0
//    - Fail: <0 (esp8266_cmd_rsp)
int16_t ESP8266Class::setMode(esp8266_wifi_mode mode, bool async)
{
	ESP8266_CHECK_BUSY(false);
	char modeChar[2] = {0, 0};
	sprintf(modeChar, "%d", mode);
	sendCommand(ESP8266_WIFI_MODE, ESP8266_CMD_SETUP, modeChar);
	if (async) {
		asyncRespInit(RESPONSE_OK, NULL, COMMAND_RESPONSE_TIMEOUT);
		return ESP8266_RSP_SUCCESS;
	} else {
		int16_t rsp = readForResponse(RESPONSE_OK, COMMAND_RESPONSE_TIMEOUT);
		async_busy = false;
		return rsp;
	}
}

int16_t ESP8266Class::connect(const char * ssid)
{
	connect(ssid, "");
}

// connect()
// Input: ssid and pwd const char's
// Output:
//    - Success: >0
//    - Fail: <0 (esp8266_cmd_rsp)
int16_t ESP8266Class::connect(const char * ssid, const char * pwd, bool async)
{
	ESP8266_CHECK_BUSY(false);
	_serial->print("AT");
	_serial->print(ESP8266_CONNECT_AP);
	_serial->print("=\"");
	_serial->print(escapeStr(ssid).c_str());
	_serial->print("\"");
	if (pwd != NULL)
	{
		_serial->print(',');
		_serial->print("\"");
		_serial->print(escapeStr(pwd).c_str());
		_serial->print("\"");
	}
	_serial->print("\r\n");
	if (async) {
		asyncRespInit(RESPONSE_OK, RESPONSE_FAIL, WIFI_CONNECT_TIMEOUT);
		return ESP8266_RSP_SUCCESS;
	} else {
		int16_t rsp = readForResponses(RESPONSE_OK, RESPONSE_FAIL,
				WIFI_CONNECT_TIMEOUT);
		async_busy = false;
		return rsp;
	}
}

int16_t ESP8266Class::listAPs(struct esp8266_ap *aps, unsigned int max_count)
{
	ESP8266_CHECK_BUSY(false);
	sendCommand(ESP8266_LIST_AP);
	int16_t rsp = readForResponse(RESPONSE_OK, COMMAND_RESPONSE_TIMEOUT);
	if (rsp > 0) {
		char *p = esp8266RxBuffer;
		char *p1;
		int i, j;

		for (i = 0; i < max_count; i++) {
			p = strstr(p, "+CWLAP:");
			if (!p)
				break;
			p += strlen("+CWLAP:");
			p1 = strchr(p, ',');
			if (!p1)
				break;
			aps[i].ecn = atoi(p);
			p = p1 + 1;
			p1 = strchr(p, ',');
			if (!p1 || p1 - p >= sizeof(aps[i].ssid))
				break;
			memcpy(aps[i].ssid, p, p1 - p);
			aps[i].ssid[p1 - p] = '\0';
			p = p1 + 1;
			p1 = strchr(p, ',');
			if (!p1)
				break;
			aps[i].rssi = atoi(p);
			p = p1 + 1;
			p1 = strchr(p, ',');
			if (!p1 || (p1 - p != sizeof(aps[i].mac) * 3 - 1))
				break;
			for (j = 0; i < sizeof(aps[i].mac); j++)
				aps[i].mac[j] = strtol(p + j * 3, NULL, 16);
			p = p1 + 1;
			p1 = strchr(p, ',');
			if (!p1)
				break;
			aps[i].ch = atoi(p);
			p = p1 + 1;
			p1 = strchr(p, '\r');
			if (!p1)
				break;
			aps[i].freq_offset = atoi(p);
			p = p1 + 1;
		}
		rsp = i;
	}
	async_busy = false;
	return rsp;
}

int16_t ESP8266Class::getAP(char * ssid)
{
	sendCommand(ESP8266_CONNECT_AP, ESP8266_CMD_QUERY); // Send "AT+CWJAP?"
	
	int16_t rsp = readForResponse(RESPONSE_OK, COMMAND_RESPONSE_TIMEOUT);
	// Example Responses: No AP\r\n\r\nOK\r\n
	// - or -
	// +CWJAP:"WiFiSSID","00:aa:bb:cc:dd:ee",6,-45\r\n\r\nOK\r\n
	if (rsp > 0)
	{
		// Look for "No AP"
		if (strstr(esp8266RxBuffer, "No AP") != NULL)
			return 0;
		
		// Look for "+CWJAP"
		char * p = strstr(esp8266RxBuffer, ESP8266_CONNECT_AP);
		if (p != NULL)
		{
			p += strlen(ESP8266_CONNECT_AP) + 2;
			char * q = strchr(p, '"');
			if (q == NULL) return ESP8266_RSP_UNKNOWN;
			strncpy(ssid, p, q-p); // Copy string to temp char array:
			return 1;
		}
	}
	
	return rsp;
}

int16_t ESP8266Class::disconnect(bool async)
{
	ESP8266_CHECK_BUSY(false);
	sendCommand(ESP8266_DISCONNECT); // Send AT+CWQAP
	// Example response: \r\n\r\nOK\r\nWIFI DISCONNECT\r\n
	// "WIFI DISCONNECT" comes up to 500ms _after_ OK. 
	int16_t rsp = readForResponse(RESPONSE_OK, COMMAND_RESPONSE_TIMEOUT);
	if (rsp > 0)
	{
		if (async) {
			asyncRespInit("WIFI DISCONNECT", NULL, COMMAND_RESPONSE_TIMEOUT);
			return ESP8266_RSP_SUCCESS;
		} else {
			rsp = readForResponse("WIFI DISCONNECT", COMMAND_RESPONSE_TIMEOUT);
			async_busy = false;
			if (rsp > 0)
				return rsp;
			return 1;
		}
	}
	
	return rsp;
}

int16_t ESP8266Class::getAPConfig(char *ssid, char *pwd)
{
	ESP8266_CHECK_BUSY(false);
	sendCommand(ESP8266_AP_CONFIG, ESP8266_CMD_QUERY, NULL);
	int16_t rsp = readForResponses(RESPONSE_OK, RESPONSE_FAIL,
			COMMAND_RESPONSE_TIMEOUT);
	if (rsp > 0) {
		char *p = searchBuffer(ESP8266_AP_CONFIG);
		if (!p) {
			rsp = ESP8266_RSP_UNKNOWN;
			goto exit;
		}
		p = strchr(p, '"');
		if (!p) {
			rsp = ESP8266_RSP_UNKNOWN;
			goto exit;
		}
		char *p1 = strchr(p + 1, '"');
		if (!p1) {
			rsp = ESP8266_RSP_UNKNOWN;
			goto exit;
		}
		*p1 = '\0';
		strcpy(ssid, p + 1);
		p = p1 + 3;	/* go to beginning of password */
		p1 = strchr(p, '"');
		if (!p1) {
			rsp = ESP8266_RSP_UNKNOWN;
			goto exit;
		}
		*p1 = '\0';
		strcpy(pwd, p);
		p = strchr(p1 + 2, ',');	/* skip channel */
		if (!p) {
			rsp = ESP8266_RSP_UNKNOWN;
			goto exit;
		}
		int ecn = atoi(p + 1);
		if (ecn == 0)	/* no Wi-Fi security */
			strcpy(pwd, "");
	}
exit:
	async_busy = false;
	return rsp;
}

// Configure ESP8266 as access point (with or without Wi-Fi security)
// Input:
//    - SSID
//    - password (if NULL or empty, no Wi-Fi security is used, otherwise
//      connections are protected with WPA/WPA2)
//    - whether to process ESP8266 response asynchronously
// Output:
//    - Success: >0
//    - Asynchronous response: 0
//    - Fail: <0 (esp8266_cmd_rsp)
int16_t ESP8266Class::configAP(const char *ssid, const char *pwd, bool async)
{
	ESP8266_CHECK_BUSY(false);
	_serial->print("AT");
	_serial->print(ESP8266_AP_CONFIG);
	_serial->print("=\"");
	_serial->print(ssid);
	if (!pwd || !strlen(pwd))
		_serial->print("\",\"\",5,0\r\n");
	else {
		_serial->print("\",\"");
		_serial->print(pwd);
		_serial->print("\",5,4\r\n");
	}
	if (async) {
		asyncRespInit(RESPONSE_OK, RESPONSE_FAIL, COMMAND_RESPONSE_TIMEOUT);
		return ESP8266_RSP_SUCCESS;
	} else {
		int16_t rsp = readForResponses(RESPONSE_OK, RESPONSE_FAIL,
				COMMAND_RESPONSE_TIMEOUT);
		async_busy = false;
		return rsp;
	}
}

// Enable or disable DHCP (both when in station and when in access point mode)
// Input: mode: mode under which DHCP must be disabled
//        enable: true to enable DHCP, false to disable DHCP
//        async: if true, don't wait for a response, which will be processed
//               asynchronously
// Output:
//    - Success: >0
//    - Fail: <0 (esp8266_cmd_rsp)
int16_t ESP8266Class::setDHCP(esp8266_wifi_mode mode, bool enable, bool async)
{
	_serial->print("AT");
	_serial->print(ESP8266_DHCP_EN);
	_serial->print("=");
	_serial->print((mode == ESP8266_MODE_AP) ? "0"
			: ((mode == ESP8266_MODE_STA) ? "1" : "2"));
	_serial->print(",");
	_serial->print(enable ? "1" : "0");
	_serial->print("\r\n");
	if (async) {
		asyncRespInit(RESPONSE_OK, NULL, COMMAND_RESPONSE_TIMEOUT);
		return ESP8266_RSP_SUCCESS;
	} else
		return readForResponse(RESPONSE_OK, COMMAND_RESPONSE_TIMEOUT);
}
// status()
// Input: none
// Output:
//    - Success: 2, 3, 4, or 5 (ESP8266_STATUS_GOTIP, ESP8266_STATUS_CONNECTED, ESP8266_STATUS_DISCONNECTED, ESP8266_STATUS_NOWIFI)
//    - Fail: <0 (esp8266_cmd_rsp)
int16_t ESP8266Class::status()
{
	int16_t statusRet = updateStatus();
	if (statusRet > 0)
	{
		switch (_status.stat)
		{
		case ESP8266_STATUS_GOTIP: // 3
		case ESP8266_STATUS_DISCONNECTED: // 4 - "Client" disconnected, not wifi
			return 1;
			break;
		case ESP8266_STATUS_CONNECTED: // Connected, but haven't gotten an IP
		case ESP8266_STATUS_NOWIFI: // No WiFi configured
			return 0;
			break;
		}
	}
	return statusRet;
}

// Update ESP8266 connection status
// Input: async: if true, don't wait for a response from ESP8266: the response
//               will be processed asynchronously
// Output:
//    - Success: >0 (0 if async is true)
//    - Fail: <0 (esp8266_cmd_rsp)
int16_t ESP8266Class::updateStatus(bool async)
{
	ESP8266_CHECK_BUSY(false);
	sendCommand(ESP8266_TCP_STATUS); // Send AT+CIPSTATUS\r\n
	if (async) {
		asyncRespInit(RESPONSE_OK, NULL, COMMAND_RESPONSE_TIMEOUT);
		return ESP8266_RSP_SUCCESS;
	}
	int16_t rsp = readForResponse(RESPONSE_OK, COMMAND_RESPONSE_TIMEOUT);
	if (rsp > 0) {
		int16_t statusRsp = statusFromResp();
		if (statusRsp < 0)
			rsp = statusRsp;
	}
	async_busy = false;
	return rsp;
}

// statusFromResp(): get connection status from the response to a previously
// sent command
// Input: none
// Output:
//    - Success: connection status (enum esp8266_connect_status)
//    - Fail: negative value
int16_t ESP8266Class::statusFromResp()
{
	// Example response: (connected as client)
	// STATUS:3\r\n
	// +CIPSTATUS:0,"TCP","93.184.216.34",80,0\r\n\r\nOK\r\n 
	// - or - (clients connected to ESP8266 server)
	// STATUS:3\r\n
	// +CIPSTATUS:0,"TCP","192.168.0.100",54723,1\r\n
	// +CIPSTATUS:1,"TCP","192.168.0.101",54724,1\r\n\r\nOK\r\n 
	char * p = searchBuffer("STATUS:");
	if (p == NULL)
		return ESP8266_RSP_UNKNOWN;
	p += strlen("STATUS:");
	_status.stat = (esp8266_connect_status)(*p - 48);
	for (int i=0; i<ESP8266_MAX_SOCK_NUM; i++)
		_status.ipstatus[i].linkID = 255;
	for (int i=0; i<ESP8266_MAX_SOCK_NUM; i++)
	{
		p = strstr(p, "+CIPSTATUS:");
		if (p == NULL)
		{
			break;
		}
		else
		{
			p += strlen("+CIPSTATUS:");
			// Find linkID:
			uint8_t linkId = *p - 48;
			if (linkId >= ESP8266_MAX_SOCK_NUM)
				break;
			_status.ipstatus[linkId].linkID = linkId;

			// Find type (p pointing at linkID):
			p += 3; // Move p to either "T" or "U"
			if (*p == 'T')
				_status.ipstatus[linkId].type = ESP8266_TCP;
			else if (*p == 'U')
				_status.ipstatus[linkId].type = ESP8266_UDP;
			else
				_status.ipstatus[linkId].type = ESP8266_TYPE_UNDEFINED;

			// Find remoteIP (p pointing at first letter or type):
			p += 6; // Move p to first digit of first octet.
			for (uint8_t j = 0; j < 4; j++)
			{
				char tempOctet[4];
				memset(tempOctet, 0, 4); // Clear tempOctet

				size_t octetLength = strspn(p, "0123456789"); // Find length of numerical string:
				
				strncpy(tempOctet, p, octetLength); // Copy string to temp char array:
				_status.ipstatus[linkId].remoteIP[j] = atoi(tempOctet); // Move the temp char into IP Address octet
				
				p += (octetLength + 1); // Increment p to next octet
			}

			// Find remote port (p pointing at ',' between IP and remote port):
			p += 1; // Move p to first digit of port
			char tempPort[6];
			memset(tempPort, 0, 6);
			size_t portLen = strspn(p, "0123456789"); // Find length of numerical string:
			strncpy(tempPort, p, portLen);
			_status.ipstatus[linkId].remotePort = atoi(tempPort);
			p += portLen + 1;

			if (_status.ipstatus[linkId].type == ESP8266_UDP) {
				// Find local port
				_status.ipstatus[linkId].port = atoi(p);
				p = strchr(p, ',');
				if (!p)
					break;	/* should never happen */
				else
					p++;
			}

			// Find tetype (p pointing at tetype)
			if (*p == '0')
				_status.ipstatus[linkId].tetype = ESP8266_CLIENT;
			else if (*p == '1')
				_status.ipstatus[linkId].tetype = ESP8266_SERVER;
		}
	}
	return _status.stat;
}

// localIP()
// Input: async: if true, don't wait for a response, which will be processed
//               asynchronously
// Output:
//    - Success: Device's local IPAddress (unless async is true)
//    - Fail: if an asynchronous command is ongoing, ESP8266_CMD_BUSY,
//      otherwise 0
IPAddress ESP8266Class::localIP(bool async)
{
	ESP8266_CHECK_BUSY(false);
	sendCommand(ESP8266_GET_LOCAL_IP); // Send AT+CIFSR\r\n
	if (async) {
		asyncRespInit(RESPONSE_OK, NULL, COMMAND_RESPONSE_TIMEOUT);
		return ESP8266_RSP_SUCCESS;
	}
	// Look for the OK:
	int16_t rsp = readForResponse(RESPONSE_OK, COMMAND_RESPONSE_TIMEOUT);
	IPAddress addr;
	if (rsp > 0)
		addr = localIPFromResp();
	async_busy = false;
	if (rsp > 0)
		return addr;
	else
		return rsp;
}

// localIPFromResp(): get local IP address from the response to a previously
// sent command
// Input: none
// Output:
//    - Success: Device's local IPAddress
//    - Fail: 0
IPAddress ESP8266Class::localIPFromResp()
{
	char *p;
	IPAddress returnIP;

	// Example Response: +CIFSR:STAIP,"192.168.0.114"\r\n
	//                   +CIFSR:STAMAC,"18:fe:34:9d:b7:d9"\r\n
	//                   \r\n
	//                   OK\r\n
	// Look for "STAIP" in the rxBuffer
	p = strstr(esp8266RxBuffer, "STAIP");
	if (p != NULL)
		p += 7; // Move p seven places. (skip STAIP,")
	else {
		// Look for "APIP" in the rxBuffer
		p = strstr(esp8266RxBuffer, "APIP");
		if (p != NULL)
			p += 6; // Move p six places. (skip APIP,")
	}
	if (p != NULL) {
		for (uint8_t i = 0; i < 4; i++)
		{
			char tempOctet[4];
			memset(tempOctet, 0, 4); // Clear tempOctet

			size_t octetLength = strspn(p, "0123456789"); // Find length of numerical string:
			if (octetLength >= 4) // If it's too big, return an error
				return ESP8266_RSP_UNKNOWN;

			strncpy(tempOctet, p, octetLength); // Copy string to temp char array:
			returnIP[i] = atoi(tempOctet); // Move the temp char into IP Address octet

			p += (octetLength + 1); // Increment p to next octet
		}
	}
	return returnIP;
}

int16_t ESP8266Class::localMAC(char * mac)
{
	sendCommand(ESP8266_GET_STA_MAC, ESP8266_CMD_QUERY); // Send "AT+CIPSTAMAC?"

	int16_t rsp = readForResponse(RESPONSE_OK, COMMAND_RESPONSE_TIMEOUT);

	if (rsp > 0)
	{
		// Look for "+CIPSTAMAC"
		char * p = strstr(esp8266RxBuffer, ESP8266_GET_STA_MAC);
		if (p != NULL)
		{
			p += strlen(ESP8266_GET_STA_MAC) + 2;
			char * q = strchr(p, '"');
			if (q == NULL) return ESP8266_RSP_UNKNOWN;
			strncpy(mac, p, q - p); // Copy string to temp char array:
			return 1;
		}
	}

	return rsp;
}

/////////////////////
// TCP/IP Commands //
/////////////////////

int16_t ESP8266Class::tcpConnect(uint8_t linkID, const char * destination,
		uint16_t port, uint16_t keepAlive, bool async)
{
	ESP8266_CHECK_BUSY(false);
	print("AT");
	print(ESP8266_TCP_CONNECT);
	print('=');
	print(linkID);
	print(',');
	print("\"TCP\",");
	print("\"");
	print(destination);
	print("\",");
	print(port);
	if (keepAlive > 0)
	{
		print(',');
		// keepAlive is in units of 500 milliseconds.
		// Max is 7200 * 500 = 3600000 ms = 60 minutes.
		print(keepAlive / 500);
	}
	print("\r\n");
	if (async) {
		asyncRespInit(RESPONSE_OK, RESPONSE_ERROR, CLIENT_CONNECT_TIMEOUT);
		return ESP8266_RSP_SUCCESS;
	}

	// Example good: CONNECT\r\n\r\nOK\r\n
	// Example bad: DNS Fail\r\n\r\nERROR\r\n
	// Example meh: ALREADY CONNECTED\r\n\r\nERROR\r\n
	int16_t rsp = readForResponses(RESPONSE_OK, RESPONSE_ERROR, CLIENT_CONNECT_TIMEOUT);

	rsp = tcpConnectResp(rsp);
	async_busy = false;
	return rsp;
}

int16_t ESP8266Class::tcpConnectResp(int16_t rsp)
{
	if (rsp < 0)
	{
		// We may see "ERROR", but be "ALREADY CONNECTED".
		// Search for "ALREADY", and return success if we see it.
		char * p = searchBuffer("ALREADY");
		if (p != NULL)
			return 2;
		// Otherwise the connection failed. Return the error code:
		return rsp;
	}
	// Return 1 on successful (new) connection
	return 1;
}

int16_t ESP8266Class::tcpSend(uint8_t linkID, const uint8_t *buf, size_t size)
{
	if (size > 2048)
		return ESP8266_CMD_BAD;
	ESP8266_CHECK_BUSY(false);
	char params[8];
	sprintf(params, "%d,%d", linkID, size);
	sendCommand(ESP8266_TCP_SEND, ESP8266_CMD_SETUP, params);
	
	int16_t rsp = readForResponses("> ", RESPONSE_ERROR,
			COMMAND_RESPONSE_TIMEOUT);
	if (rsp != ESP8266_RSP_FAIL)
	{
		Print::write(buf, size);
		
		rsp = readForResponse("SEND OK", COMMAND_RESPONSE_TIMEOUT);
		
		if (rsp > 0)
			rsp = size;
	}
	
	async_busy = false;
	return rsp;
}

int16_t ESP8266Class::tcpPrepareSend(uint8_t linkID, size_t size)
{
	if (size > 2048)
		return ESP8266_CMD_BAD;
	ESP8266_CHECK_BUSY(false);
	char params[8];
	sprintf(params, "%d,%d", linkID, size);
	sendCommand(ESP8266_TCP_SEND, ESP8266_CMD_SETUP, params);
	asyncRespInit("> ", RESPONSE_ERROR, COMMAND_RESPONSE_TIMEOUT);
	return ESP8266_RSP_SUCCESS;
}

int16_t ESP8266Class::sendBuf(const uint8_t *buf)
{
	print((const char *)buf);
	asyncRespInit("SEND OK", NULL, COMMAND_RESPONSE_TIMEOUT);
	return ESP8266_RSP_SUCCESS;
}

int16_t ESP8266Class::close(uint8_t linkID, bool async)
{
	ESP8266_CHECK_BUSY(false);
	char params[2];
	sprintf(params, "%d", linkID);
	sendCommand(ESP8266_TCP_CLOSE, ESP8266_CMD_SETUP, params);
	
	if (async) {
		asyncRespInit(RESPONSE_OK, NULL, COMMAND_RESPONSE_TIMEOUT);
		return ESP8266_RSP_SUCCESS;
	} else {
		// Eh, client virtual function doesn't have a return value.
		// We'll wait for the OK or timeout anyway.
		int16_t ret = readForResponse(RESPONSE_OK, COMMAND_RESPONSE_TIMEOUT);
		if (((ret > 0)
				|| ((ret == ESP8266_RSP_UNKNOWN) && searchBuffer("UNLINK")))
				&& (linkID < ESP8266_MAX_SOCK_NUM))
			_status.ipstatus[linkID].linkID = ESP8266_SOCK_NOT_AVAIL;
		async_busy = false;
		return ret;
	}
}

int16_t ESP8266Class::setTransferMode(uint8_t mode)
{
	char params[2] = {0, 0};
	params[0] = (mode > 0) ? '1' : '0';
	sendCommand(ESP8266_TRANSMISSION_MODE, ESP8266_CMD_SETUP, params);
	
	return readForResponse(RESPONSE_OK, COMMAND_RESPONSE_TIMEOUT);
}

int16_t ESP8266Class::setMux(uint8_t mux)
{
	char params[2] = {0, 0};
	params[0] = (mux > 0) ? '1' : '0';
	sendCommand(ESP8266_TCP_MULTIPLE, ESP8266_CMD_SETUP, params);
	
	return readForResponse(RESPONSE_OK, COMMAND_RESPONSE_TIMEOUT);
}

int16_t ESP8266Class::configureTCPServer(uint16_t port, uint8_t create)
{
	char params[10];
	ESP8266_CHECK_BUSY(false);
	if (create > 1) create = 1;
	if (create)
		sprintf(params, "%d,%d", create, port);
	else
		strcpy(params, "0");
	sendCommand(ESP8266_SERVER_CONFIG, ESP8266_CMD_SETUP, params);
	
	int16_t ret = readForResponse(RESPONSE_OK, COMMAND_RESPONSE_TIMEOUT);
	async_busy = false;
	return ret;
}

int16_t ESP8266Class::configureUDPServer(uint16_t port)
{
	int i;
	int socket;
	char params[32];
	int16_t ret;

	ret = esp8266.updateStatus();
	if (ret < 0)
		return ret;
	ESP8266_CHECK_BUSY(false);
	socket = ESP8266_SOCK_NOT_AVAIL;
	for (i = 0; i < ESP8266_MAX_SOCK_NUM; i++) {
		if ((_status.ipstatus[i].linkID == i)
				&& (_status.ipstatus[i].type == ESP8266_UDP)
				&& (_status.ipstatus[i].port == port)) {
			/* An UDP server is already listening on this port: no need to do
			 * anything. */
			async_busy = false;
			return i;
		}
	}
	for (i = 0; i < ESP8266_MAX_SOCK_NUM; i++) {
		if (_status.ipstatus[i].linkID == 255) {
			socket = i;
			break;
		}
	}
	if (socket == ESP8266_SOCK_NOT_AVAIL) {
		async_busy = false;
		return ESP8266_CMD_BAD;
	}
	sprintf(params, "%d,\"UDP\",\"0.0.0.0\",0,%d,2", socket, port);
	sendCommand(ESP8266_UDP_CONFIG, ESP8266_CMD_SETUP, params);
	ret = readForResponse(RESPONSE_OK, COMMAND_RESPONSE_TIMEOUT);
	if (ret > 0) {
		_status.ipstatus[socket].linkID = socket;
		_status.ipstatus[socket].type = ESP8266_UDP;
	}
	async_busy = false;
	if (ret < 0)
		return ret;
	else
		return socket;
}

int16_t ESP8266Class::ping(IPAddress ip)
{
	char ipStr[17];
	sprintf(ipStr, "%d.%d.%d.%d", ip[0], ip[1], ip[2], ip[3]);
	return ping(ipStr);
}

int16_t ESP8266Class::ping(char * server)
{
	char params[strlen(server) + 3];
	sprintf(params, "\"%s\"", server);
	// Send AT+Ping=<server>
	sendCommand(ESP8266_PING, ESP8266_CMD_SETUP, params); 
	// Example responses:
	//  * Good response: +12\r\n\r\nOK\r\n
	//  * Timeout response: +timeout\r\n\r\nERROR\r\n
	//  * Error response (unreachable): ERROR\r\n\r\n
	int16_t rsp = readForResponses(RESPONSE_OK, RESPONSE_ERROR, COMMAND_PING_TIMEOUT);
	if (rsp > 0)
	{
		char * p = searchBuffer("+");
		p += 1; // Move p forward 1 space
		char * q = strchr(p, '\r'); // Find the first \r
		if (q == NULL)
			return ESP8266_RSP_UNKNOWN;
		char tempRsp[10];
		strncpy(tempRsp, p, q - p);
		return atoi(tempRsp);
	}
	else
	{
		if (searchBuffer("timeout") != NULL)
			return 0;
	}
	
	return rsp;
}

//////////////////////////
// Custom GPIO Commands //
//////////////////////////
int16_t ESP8266Class::pinMode(uint8_t pin, uint8_t mode)
{
	char params[5];
	
	char modeC = 'i'; // Default mode to input
	if (mode == OUTPUT) 
		modeC = 'o'; // o = OUTPUT
	else if (mode == INPUT_PULLUP) 
		modeC = 'p'; // p = INPUT_PULLUP
	
	sprintf(params, "%d,%c", pin, modeC);
	sendCommand(ESP8266_PINMODE, ESP8266_CMD_SETUP, params);
	
	return readForResponses(RESPONSE_OK, RESPONSE_ERROR, COMMAND_RESPONSE_TIMEOUT);
}

int16_t ESP8266Class::digitalWrite(uint8_t pin, uint8_t state)
{
	char params[5];
	
	char stateC = 'l'; // Default state to LOW
	if (state == HIGH) 
		stateC = 'h'; // h = HIGH
	
	sprintf(params, "%d,%c", pin, stateC);
	sendCommand(ESP8266_PINWRITE, ESP8266_CMD_SETUP, params);
	
	return readForResponses(RESPONSE_OK, RESPONSE_ERROR, COMMAND_RESPONSE_TIMEOUT);
}

int8_t ESP8266Class::digitalRead(uint8_t pin)
{
	char params[3];
	
	sprintf(params, "%d", pin);
	sendCommand(ESP8266_PINREAD, ESP8266_CMD_SETUP, params); // Send AT+PINREAD=n\r\n
	// Example response: 1\r\n\r\nOK\r\n
	if (readForResponses(RESPONSE_OK, RESPONSE_ERROR, COMMAND_RESPONSE_TIMEOUT) > 0)
	{
		if (strchr(esp8266RxBuffer, '0') != NULL)
			return LOW;
		else if (strchr(esp8266RxBuffer, '1') != NULL)
			return HIGH;
	}
	
	return -1;
}

void ESP8266Class::asyncRespInit(const char *resp_ok, const char *resp_error,
			unsigned int timeout)
{
	async_resp_ok = resp_ok;
	async_resp_error = resp_error;
	async_resp_start = millis();
	async_resp_timeout = timeout;
	clearBuffer();
}

int16_t ESP8266Class::checkAsyncResp()
{
	unsigned int received = bufferHead;

	while (_serial->available()) {
		received += readByteToBuffer();
		if (searchBuffer(async_resp_ok)) {
			if (async_resp_ok[0] != '>')
				async_busy = false;
			return received;
		}
		if (async_resp_error && searchBuffer(async_resp_error)) {
			async_busy = false;
			return ESP8266_RSP_FAIL;
		}
	}
	if (millis() < async_resp_start + async_resp_timeout)
		return 0;
	else {
		async_busy = false;
		if (received > 0)
			return ESP8266_RSP_UNKNOWN;
		else
			return ESP8266_RSP_TIMEOUT;
	}
}

//////////////////////////////
// Stream Virtual Functions //
//////////////////////////////

size_t ESP8266Class::write(uint8_t c)
{
	_serial->write(c);
}

int ESP8266Class::available()
{
	return _serial->available();
}

int ESP8266Class::read()
{
	return _serial->read();
}

int ESP8266Class::peek()
{
	return _serial->peek();
}

void ESP8266Class::flush()
{
	_serial->flush();
}

int16_t ESP8266Class::readForConnect(unsigned int timeout)
{
	unsigned long timeIn = millis();
	int16_t sock = ESP8266_RSP_TIMEOUT;

	do {
		ESP8266_CHECK_BUSY(true);
		if (readIndication(",CONNECT\r\n") > 0) {
			char * p = esp8266.searchBuffer(",CONNECT\r\n");
			p -= 1;
			sock = *p - 48;
			_status.ipstatus[sock].linkID = sock;
			_status.ipstatus[sock].tetype = ESP8266_SERVER;
			ind_ongoing = false;
		}
		async_busy = false;
	} while ((sock == ESP8266_RSP_TIMEOUT) && (millis() < timeIn + timeout));
	return sock;
}

int ESP8266Class::availableOnSocket(unsigned int socket)
{
	int available;

	ESP8266_CHECK_BUSY(true);
	if (ind_ongoing && (ind_socket == socket)) {
		available = _serial->available();
		if (available > ind_data_len)
			available = ind_data_len;
		if (available)
			ind_time = millis();
	} else {
		available = 0;
		readIndication(":");
	}
	async_busy = false;
	return available;
}

int ESP8266Class::readFromSocket(unsigned int socket)
{
	int c;

	if (ind_ongoing && (ind_socket == socket)) {
		c = _serial->read();
		if (--ind_data_len == 0)
			ind_ongoing = false;
	} else
		c = -1;
	return c;
}

//////////////////////////////////////////////////
// Private, Low-Level, Ugly, Hardware Functions //
//////////////////////////////////////////////////

void ESP8266Class::sendCommand(const char * cmd, enum esp8266_command_type type, const char * params)
{
	_serial->print("AT");
	_serial->print(cmd);
	if (type == ESP8266_CMD_QUERY)
		_serial->print('?');
	else if (type == ESP8266_CMD_SETUP)
	{
		_serial->print("=");
		_serial->print(params);		
	}
	_serial->print("\r\n");
}

int16_t ESP8266Class::readForResponse(const char * rsp, unsigned int timeout)
{
	unsigned long timeIn = millis();	// Timestamp coming into function
	unsigned int received = 0; // received keeps track of number of chars read
	
	clearBuffer();	// Clear the class receive buffer (esp8266RxBuffer)
	while (timeIn + timeout > millis()) // While we haven't timed out
	{
		if (_serial->available()) // If data is available on UART RX
		{
			received += readByteToBuffer();
			if (searchBuffer(rsp))	// Search the buffer for goodRsp
				return received;	// Return how number of chars read
		}
	}
	
	if (received > 0) // If we received any characters
		return ESP8266_RSP_UNKNOWN; // Return unkown response error code
	else // If we haven't received any characters
		return ESP8266_RSP_TIMEOUT; // Return the timeout error code
}

int16_t ESP8266Class::readForResponses(const char * pass, const char * fail, unsigned int timeout)
{
	unsigned long timeIn = millis();	// Timestamp coming into function
	unsigned int received = 0; // received keeps track of number of chars read
	
	clearBuffer();	// Clear the class receive buffer (esp8266RxBuffer)
	while (timeIn + timeout > millis()) // While we haven't timed out
	{
		if (_serial->available()) // If data is available on UART RX
		{
			received += readByteToBuffer();
			if (searchBuffer(pass))	// Search the buffer for goodRsp
				return received;	// Return how number of chars read
			if (searchBuffer(fail))
				return ESP8266_RSP_FAIL;
		}
	}
	
	if (received > 0) // If we received any characters
		return ESP8266_RSP_UNKNOWN; // Return unkown response error code
	else // If we haven't received any characters
		return ESP8266_RSP_TIMEOUT; // Return the timeout error code
}

int ESP8266Class::readIndication(const char *ind)
{
	char *str;

	if (!ind_ongoing && _serial->available()) {
		clearBuffer();
		ind_socket = ESP8266_SOCK_NOT_AVAIL;
		ind_data_len = 0;
		ind_ongoing = true;
	}
	if (!ind_ongoing || (ind_data_len != 0))
		/* Either no indications are being received, or there is incoming data
		 * from a socket, not to be processed here */
		return 0;
	if (_serial->available())
		ind_time = millis();
	if (searchBuffer(ind))
		return bufferHead;
	while (_serial->available()) {
		readByteToBuffer();
		if ((bufferHead > 0) && (esp8266RxBuffer[bufferHead - 1] == ':')) {
			char *str = searchBuffer("+IPD,");

			if (str) {
				ind_socket = atoi(str + 5);
				str = strchr(str + 5, ',');
				if (str) {
					ind_data_len = atoi(str + 1);
					return 0;
				}
			}
		}
		if (searchBuffer(ind))
			return bufferHead;
	}
	return 0;
}

//////////////////
// Buffer Stuff //
//////////////////
void ESP8266Class::clearBuffer()
{
	memset(esp8266RxBuffer, '\0', ESP8266_RX_BUFFER_LEN);
	bufferHead = 0;
}	

unsigned int ESP8266Class::readByteToBuffer()
{
	// Read the data in
	char c = _serial->read();
	
	// Store the data in the buffer
	esp8266RxBuffer[bufferHead] = c;
	//! TODO: Don't care if we overflow. Should we? Set a flag or something?
	bufferHead = (bufferHead + 1) % (ESP8266_RX_BUFFER_LEN - 1);
	
	return 1;
}

char * ESP8266Class::searchBuffer(const char * test)
{
	//! TODO
	// Handle cases where the buffer is full, we need to search from the head of
	// the buffer back to the tail.
	return strstr((const char *)esp8266RxBuffer, test);
}

String ESP8266Class::escapeStr(const char *str)
{
	String escapedStr(str);
	escapedStr.replace("/", "//");
	escapedStr.replace(",", "/,");
	escapedStr.replace("\"", "/\"");
	return escapedStr;
}

ESP8266Class esp8266;
