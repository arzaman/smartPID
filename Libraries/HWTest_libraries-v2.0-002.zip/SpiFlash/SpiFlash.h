/*
 * Library for reading and writing on SPI flash memory
 *
 *  Copyright (C) 2016 Arzaman
 */

#ifndef SPIFLASH_H_
#define SPIFLASH_H_

#include <SPI.h>

class SpiFlash {
public:

	/* Initialize an SpiFlash object
	 * Parameters:
	 * - spi: reference to the object that handles the SPI peripheral
	 * - csPin: digital pin to be operated as chip select signal
	 * Returns: none
	 */
	void init(SPIClass &spi, uint32_t csPin);

	/* Get flash memory size
	 * Parameters: none
	 * Returns: memory size, in bytes
	 */
	uint32_t memSize();

	/* Get flash erase block size
	 * Parameters: none
	 * Returns: size (in bytes) of the smallest memory block that can be erased
	 *          in a single operation
	 */
	uint32_t eraseSize();

	/* Read data from the SPI flash
	 * Parameters:
	 * - addr: flash address where data must be read from
	 * - buf: buffer where data are copied to
	 * - len: length of data to be read
	 * Returns: none
	 */
	void read(uint32_t addr, uint8_t *buf, unsigned int len);

	/* Read data from a page of the SPI flash
	 * Data must fit in one flash page, i.e. must not cross page boundaries; to
	 * read an arbitrary number of bytes from an arbitrary address, use read()
	 * instead
	 * Parameters:
	 * - addr: flash address where data must be read from
	 * - buf: buffer where data are copied to
	 * - len: length of data to be read
	 * Returns: none
	 */
	void readPage(uint32_t addr, uint8_t *buf, unsigned int len);

	/* Read an 8-bit value from the SPI flash
	 * Parameters:
	 * - addr: flash address where data must be read from
	 * Returns: 8-bit value read from flash at the supplied address
	 */
	uint8_t read8(uint32_t addr);

	/* Write data to the SPI flash
	 * Parameters:
	 * - addr: flash address where data must be written
	 * - buf: input buffer containing data to be written
	 * - len: length of data to be written
	 * Returns: none
	 */
	void write(uint32_t addr, uint8_t *buf, unsigned int len);

	/* Write data to a page of the SPI flash
	 * Data must fit in one flash page, i.e. must not cross page boundaries; to
	 * write an arbitrary number of bytes to an arbitrary address, use write()
	 * instead
	 * Parameters:
	 * - addr: flash address where data must be written
	 * - buf: input buffer containing data to be written
	 * - len: length of data to be written
	 * Returns: none
	 */
	void writePage(uint32_t addr, uint8_t *buf, unsigned int len);

	/* Write an 8-bit value to the SPI flash
	 * Parameters:
	 * - addr: flash address where data must be written
	 * - value: 8-bit value to be written
	 * Returns: none
	 */
	void write8(uint32_t addr, uint8_t value);

	/* Erase a memory block
	 * This method erases the smallest-size memory block supported by the chip
	 * Parameters:
	 * - addr: memory address belonging to the block to be erased
	 * Returns: none
	 */
	void erase(uint32_t addr);

private:
	SPIClass *spi;
	uint32_t cs;
};

extern SpiFlash spiFlash;

#endif /* SPIFLASH_H_ */
