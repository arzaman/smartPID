#include <dma.h>
#include <config/conf_board.h>
#include <i2c_common.h>
#include <i2c_master.h>
#include <Adafruit_SSD1306.h>

uint8_t buffer_i2c[32] = {
		0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09,
};

uint8_t fb_count, fb_indx, fb_mod, oled_init=0;
uint8_t *fb_p;


volatile uint8_t synch_frame;

extern struct i2c_master_module i2c_master_instance;
extern int i2c_dma_init_sm(void);
extern uint8_t oled_buffer[];

void WaitSynchDisplay(void)
{
synch_frame=1;
while(synch_frame){}
}

void WaitFreeDMA(void)
{
//    while(DMAC->CHSTATUS.bit.PEND || DMAC->ACTIVE.bit.BTCNT){}
//    while(DMAC->CHCTRLA.bit.ENABLE){}
//    while(DMAC->PENDCH.bit.PENDCH0){}
//    while(SERCOM3->I2CM.INTFLAG.bit.MB){}
//    while(SERCOM3->I2CM.STATUS.bit.CLKHOLD){}
    while(SERCOM3->I2CM.STATUS.bit.BUSSTATE==2){}
}

void delay_oled(void)
{
int t=1000;
while(t--){}
}

void CommandOLED_DMA(uint8_t c)
{
WaitFreeDMA();
//SERCOM3->I2CM.CTRLA.bit.SWRST=1;
buffer_i2c[0]=0;
buffer_i2c[1]=c;
descriptor_section[0].BTCNT.bit.BTCNT=2;
descriptor_section[0].SRCADDR.bit.SRCADDR=(uint32_t)buffer_i2c + descriptor_section[0].BTCNT.bit.BTCNT;
DMAC->CHCTRLA.bit.ENABLE=1;
//DMAC->CHCTRLA.reg |= DMAC_CHCTRLA_ENABLE;

i2c_master_dma_set_transfer(&i2c_master_instance, SLAVE_ADDRESS, 2/*DATA_LENGTH*/, I2C_TRANSFER_WRITE);
//delay_oled();
}

void DataOLED_DMA(uint8_t *p)
{
WaitFreeDMA();
//SERCOM3->I2CM.CTRLA.bit.SWRST=1;
buffer_i2c[0]=0x40;
for(int i=0; i<16;i++) buffer_i2c[i+1]=p[i];
descriptor_section[0].BTCNT.bit.BTCNT=17;
descriptor_section[0].SRCADDR.bit.SRCADDR=(uint32_t)buffer_i2c + descriptor_section[0].BTCNT.bit.BTCNT;
DMAC->CHCTRLA.bit.ENABLE=1;
//DMAC->CHCTRLA.reg |= DMAC_CHCTRLA_ENABLE;

i2c_master_dma_set_transfer(&i2c_master_instance, SLAVE_ADDRESS, 17/*DATA_LENGTH*/, I2C_TRANSFER_WRITE);
//delay_oled();
}

void InitOLED_128x64(void)
{
i2c_dma_init_sm();
//DataOLED_DMA(buffer_i2c);

#if defined SSD1306
delay_oled(); CommandOLED_DMA(SSD1306_DISPLAYOFF);                    // 0xAE
delay_oled(); CommandOLED_DMA(SSD1306_SETDISPLAYCLOCKDIV);            // 0xD5
delay_oled(); CommandOLED_DMA(0x80);                                  // the suggested ratio 0x80
delay_oled(); CommandOLED_DMA(SSD1306_SETMULTIPLEX);                  // 0xA8
delay_oled(); CommandOLED_DMA(0x3F);
delay_oled(); CommandOLED_DMA(SSD1306_SETDISPLAYOFFSET);              // 0xD3
delay_oled(); CommandOLED_DMA(0x0);                                   // no offset
delay_oled(); CommandOLED_DMA(SSD1306_SETSTARTLINE | 0x0);            // line #0
delay_oled(); CommandOLED_DMA(SSD1306_CHARGEPUMP);                    // 0x8D
//    if (vccstate == SSD1306_EXTERNALVCC) 
//      { delay_oled(); CommandOLED_DMA(0x10); }
//    else 
      { delay_oled(); CommandOLED_DMA(0x14); }
delay_oled(); CommandOLED_DMA(SSD1306_MEMORYMODE);                    // 0x20
delay_oled(); CommandOLED_DMA(0x00);                                  // 0x0 act like ks0108
delay_oled(); CommandOLED_DMA(SSD1306_SEGREMAP/* | 0x1*/);
delay_oled(); CommandOLED_DMA(SSD1306_COMSCANINC/*SSD1306_COMSCANDEC*/);
delay_oled(); CommandOLED_DMA(SSD1306_SETCOMPINS);                    // 0xDA
delay_oled(); CommandOLED_DMA(0x12);
delay_oled(); CommandOLED_DMA(SSD1306_SETCONTRAST);                   // 0x81
//    if (vccstate == SSD1306_EXTERNALVCC) 
//      { delay_oled(); CommandOLED_DMA(0x9F); }
//    else 
      { delay_oled(); CommandOLED_DMA(0xCF); }
delay_oled(); CommandOLED_DMA(SSD1306_SETPRECHARGE);                  // 0xd9
//    if (vccstate == SSD1306_EXTERNALVCC) 
//      { delay_oled(); CommandOLED_DMA(0x22); }
//    else 
      { delay_oled(); CommandOLED_DMA(0xF1); }
delay_oled(); CommandOLED_DMA(SSD1306_SETVCOMDETECT);                 // 0xDB
delay_oled(); CommandOLED_DMA(0x40);
delay_oled(); CommandOLED_DMA(SSD1306_DISPLAYALLON_RESUME);           // 0xA4
delay_oled(); CommandOLED_DMA(SSD1306_DISPLAYON/*SSD1306_NORMALDISPLAY*/);                 // 0xA6

#else

CommandOLED_DMA(0xAE); /*display off*/
delay_oled(); CommandOLED_DMA(0x02); /*set lower column address*/
delay_oled(); CommandOLED_DMA(0x10); /*set higher column address*/
delay_oled(); CommandOLED_DMA(0x40); /*set display start line*/
delay_oled(); CommandOLED_DMA(0xB0); /*set page address*/
delay_oled(); CommandOLED_DMA(0x81); /*contrast control*/
delay_oled(); CommandOLED_DMA(0x80); /*128*/
delay_oled(); CommandOLED_DMA(0xA0/*0xA1*/); /*set segment remap*/
delay_oled(); CommandOLED_DMA(0xA6); /*normal / reverse*/
delay_oled(); CommandOLED_DMA(0xA8); /*multiplex ratio*/
delay_oled(); CommandOLED_DMA(0x3F); /*duty = 1/32*/
delay_oled(); CommandOLED_DMA(0xad); /*set charge pump enable*/
delay_oled(); CommandOLED_DMA(0x8b); /*external VCC */
delay_oled(); CommandOLED_DMA(0x30); /*0X30---0X33 set VPP 9V liangdu!!!!*/
delay_oled(); CommandOLED_DMA(0xC0/*0xC8*/); /*Com scan direction*/
delay_oled(); CommandOLED_DMA(0xD3); /*set display offset*/
delay_oled(); CommandOLED_DMA(0x00); /* 0x20 */
delay_oled(); CommandOLED_DMA(0xD5); /*set osc division*/
delay_oled(); CommandOLED_DMA(0x80);
delay_oled(); CommandOLED_DMA(0xD9); /*set pre-charge period*/
delay_oled(); CommandOLED_DMA(0x1f); /*0x22*/
delay_oled(); CommandOLED_DMA(0xDA); /*set COM pins*/
delay_oled(); CommandOLED_DMA(0x12);
delay_oled(); CommandOLED_DMA(0xdb); /*set vcomh*/
delay_oled(); CommandOLED_DMA(0x40);
delay_oled(); CommandOLED_DMA(0xAF); /*display ON*/
#endif

delay_oled(); 
fb_p=oled_buffer;
oled_init=1;
}

void OLED_DMA_128x64_display(void)
{
uint8_t *p=oled_buffer;
    CommandOLED_DMA(0/*SSD1306_SETLOWCOLUMN | 0x0*/);  // low col = 0
    CommandOLED_DMA(0x10/*SSD1306_SETHIGHCOLUMN | 0x0*/);  // hi col = 0
    CommandOLED_DMA(0x40/*SSD1306_SETSTARTLINE | 0x0*/); // line #0

//    const PROGMEM byte *p = buffer;
//    height >>= 3;
//    width >>= 3;
    for (int i = 0; i < 8; i++) {
      // send a bunch of data in one xmission
        CommandOLED_DMA(0xB0 + i + 0/*m_row*/);//set page address
        CommandOLED_DMA(0x02/*m_col & 0xf*/);//set lower column address
        CommandOLED_DMA(0x10 /*| (m_col >> 4)*/);//set higher column address

        
        for(int j = 0; j < 8; j++){

          DataOLED_DMA(p);
          p+=16;
//            Wire.beginTransmission(_i2caddr);
//            WIRE_WRITE(0x40);
//            for (byte k = 0; k < (128>>3)/*width*/; k++/*, p++*/) {
//                WIRE_WRITE(buffer[p++]);
//            }
//            Wire.endTransmission();
        }

    }
 
}

void frame_buffer_refresh(void)
{
#if SSD1306  
if(oled_init==0) return;
if(fb_count>=100) {fb_count=0; fb_p=oled_buffer;} else fb_count++;

if(fb_count==1) {CommandOLED_DMA(0x21/*SSD1306_COLUMNADDR*/); return;}
if(fb_count==2) {CommandOLED_DMA(0); return;}
if(fb_count==3) {CommandOLED_DMA(/*SSD1306_LCDWIDTH*/128-1); return;}
if(fb_count==4) {CommandOLED_DMA(0x22/*SSD1306_PAGEADDR*/); return;}
if(fb_count==5) {CommandOLED_DMA(0); return;}
if(fb_count==6) {CommandOLED_DMA(7); return;}

fb_mod=(fb_count-7) % 11;
fb_indx=(fb_count-7) / 11;
if(fb_indx>=8) {/*fb_count=0; fb_p=buffer;*/ synch_frame=0; return;}

//if(fb_mod==0) {CommandOLED_DMA(0xB0 + fb_indx + 0/*m_row*/); return;}
//if(fb_mod==1) {CommandOLED_DMA(0x02/*m_col & 0xf*/); return;}
//if(fb_mod==2) {CommandOLED_DMA(0x10 /*| (m_col >> 4)*/); return;}

if(fb_mod>2 && fb_mod<=10) {DataOLED_DMA(fb_p); fb_p+=16; return;} 

#else  
if(oled_init==0) return;
if(fb_count>=100) {fb_count=0; fb_p=buffer;} else fb_count++;

if(fb_count==1) {CommandOLED_DMA(2/*SSD1306_SETLOWCOLUMN | 0x0*/); return;}
if(fb_count==2) {CommandOLED_DMA(0x10/*SSD1306_SETHIGHCOLUMN | 0x0*/); return;}
if(fb_count==3) {CommandOLED_DMA(0x40/*SSD1306_SETSTARTLINE | 0x0*/); return;}

fb_mod=(fb_count-4) % 11;
fb_indx=(fb_count-4) / 11;
if(fb_indx>=8) {/*fb_count=0; fb_p=buffer;*/ synch_frame=0; return;}

if(fb_mod==0) {CommandOLED_DMA(0xB0 + fb_indx + 0/*m_row*/); return;}
if(fb_mod==1) {CommandOLED_DMA(0x02/*m_col & 0xf*/); return;}
if(fb_mod==2) {CommandOLED_DMA(0x10 /*| (m_col >> 4)*/); return;}

if(fb_mod>2 && fb_mod<=10) {DataOLED_DMA(fb_p); fb_p+=16; return;} 
#endif
}
