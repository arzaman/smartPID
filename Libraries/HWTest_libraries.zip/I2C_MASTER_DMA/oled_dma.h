#ifndef OLED_DMA_H_INCLUDED
#define OLED_DMA_H_INCLUDED


void InitOLED_128x64(void);
void DataOLED_DMA(uint8_t *p);
void CommandOLED_DMA(uint8_t c);
void OLED_DMA_128x64_display(void);

#endif
