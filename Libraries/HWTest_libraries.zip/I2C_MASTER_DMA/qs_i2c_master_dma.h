#ifndef _I2C_DMA_H
#define _I2C_DMA_H

int i2c_dma_init(void);

#endif