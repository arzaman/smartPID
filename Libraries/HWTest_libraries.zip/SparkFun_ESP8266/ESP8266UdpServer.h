/******************************************************************************
ESP8266 UDP Server Header File
Copyright (C) 2016 Arzaman
******************************************************************************/

#ifndef _ESP8266UDPSERVER_H_
#define _ESP8266UDPSERVER_H_

#include <stdint.h>

#include "Server.h"

class ESP8266UdpServer : public Server
{
public:

	/* Class constructor
	 * Parameters:
	 * - port: UDP port at which the server will be listening
	 */
	ESP8266UdpServer(uint16_t port);

	/* Activate an UDP server
	 * Parameters: none
	 * Returns: none
	 */
	void begin();

	/* Activate an UDP server and return results
	 * This method does the same as begin(), but in addition returns a result
	 * code.
	 * Parameters: none
	 * Returns: true if server has been initialized successfully, false
	 * otherwise
	 */
	bool beginCheck();

	/* Check whether an UDP server has been activated
	 * This method returns true if begin() or beginCheck() have been called in
	 * the past without errors.
	 * Parameters: none
	 * Returns: true if server has been initialized successfully, false
	 * otherwise
	 */
	bool running();

	/* Retrieve the number of bytes available to be read
	 * Parameters: none
	 * Returns: number of bytes sent by the remote UDP client and available to
	 * be read locally
	 */
	int available();

	/* Retrieve the next byte available to be read
	 * Parameters: none
	 * Returns: next byte sent by the remote UDP client and available to
	 * be read locally
	 */
	int read();

	/* Send a data byte to remote UDP peer
	 * This method sends the data to the last remote peer that previously sent
	 * data to the local UDP server, and thus its results are undefined if no
	 * data has ever been received by this server.
	 * Parameters:
	 * - b: data byte to be sent to remote UDP peer
	 * Returns: 1 if data could be sent successfully, negative error code
	 * otherwise
	 */
	size_t write(uint8_t b);

	/* Send data to remote UDP peer
	 * This method sends the data to the last remote peer that previously sent
	 * data to the local UDP server, and thus its results are undefined if no
	 * data has ever been received by this server.
	 * Parameters:
	 * - buf: buffer containing data to be sent to remote UDP peer
	 * - size: number of bytes to be sent to remote UDP peer
	 * Returns: number of bytes sent, or negative error code
	 */
	size_t write(const uint8_t *buf, size_t size);

	/* Shut down UDP server
	 * Parameters: none
	 * Returns: none
	 */
	void end();

	using Print::write;
	
private:
	uint16_t _port;
	uint8_t _socket;
};

#endif
