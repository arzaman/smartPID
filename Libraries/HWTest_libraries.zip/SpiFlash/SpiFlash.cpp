/*
 * Library for reading and writing on SPI flash memory
 *
 *  Copyright (C) 2016 Arzaman
 */

#include "SpiFlash.h"
#include "wiring.h"

#define M25PX80_PAGE_SIZE	0x100

#define M25PX80_PP		0x02
#define M25PX80_READ	0x03
#define M25PX80_RDSR	0x05
#define M25PX80_WREN	0x06
#define M25PX80_SSE		0x20

#define M25PX80_REG_STATUS_SRWD		(1 << 7)
#define M25PX80_REG_STATUS_TB		(1 << 5)
#define M25PX80_REG_STATUS_BP_SHIFT	2
#define M25PX80_REG_STATUS_BP_MASK	(0x7 << M25PX80_REG_STATUS_BP_SHIFT)
#define M25PX80_REG_STATUS_WEL	(1 << 1)
#define M25PX80_REG_STATUS_WIP	(1 << 0)

/* Send a flash memory address to the SPI flash
 * Parameters:
 * - spi: SPI port to which the flash chip is connected
 * - addr: flash memory address
 */
static void sendAddr(SPIClass &spi, uint32_t addr) {
	spi.transfer(addr >> 16);
	spi.transfer(addr>> 8);
	spi.transfer(addr);
}

/* Retrieve flash memory status
 * Parameters:
 * - spi: SPI port to which the flash chip is connected
 * - cs: microcontroller pin number for the chip select signal
 */
static uint8_t getStatus(SPIClass &spi, uint32_t cs) {
	digitalWrite(cs, LOW);
	spi.transfer(M25PX80_RDSR);
	uint8_t status = spi.transfer(0);
	digitalWrite(cs, HIGH);
	return status;
}

/* Enable writing to the flash memory
 * This function must be called before sending any command that writes or erases
 * the memory.
 * Parameters:
 * - spi: SPI port to which the flash chip is connected
 * - cs: microcontroller pin number for the chip select signal
 */
static void enableWrite(SPIClass &spi, uint32_t cs) {
	digitalWrite(cs, LOW);
	spi.transfer(M25PX80_WREN);
	digitalWrite(cs, HIGH);
}

SpiFlash spiFlash;

void SpiFlash::init(SPIClass &spi, uint32_t csPin) {
	spi.begin();
	pinMode(csPin, OUTPUT);
	cs = csPin;
	this->spi = &spi;
};

uint32_t SpiFlash::memSize()
{
	return (1024 * 1024);
}

uint32_t SpiFlash::eraseSize()
{
	return (4 * 1024);
}

void SpiFlash::read(uint32_t addr, uint8_t *buf, unsigned int len)
{
	int readSize;

	while (len > 0) {
		readSize = M25PX80_PAGE_SIZE - (addr & (M25PX80_PAGE_SIZE - 1));
		if (readSize > len)
			readSize = len;
		readPage(addr, buf, readSize);
		addr += readSize;
		buf += readSize;
		len -= readSize;
	}
}

void SpiFlash::readPage(uint32_t addr, uint8_t *buf, unsigned int len)
{
	while (getStatus(*spi, cs) & M25PX80_REG_STATUS_WIP) {}
	digitalWrite(cs, LOW);
	spi->transfer(M25PX80_READ);
	sendAddr(*spi, addr);
	for (int i = 0; i < len; i++)
		buf[i] = spi->transfer(0);
	digitalWrite(cs, HIGH);
}

uint8_t SpiFlash::read8(uint32_t addr)
{
	uint8_t value;

	while (getStatus(*spi, cs) & M25PX80_REG_STATUS_WIP) {}
	digitalWrite(cs, LOW);
	spi->transfer(M25PX80_READ);
	sendAddr(*spi, addr);
	value = spi->transfer(0);
	digitalWrite(cs, HIGH);
	return value;
}

void SpiFlash::write(uint32_t addr, uint8_t *buf, unsigned int len)
{
	int writeSize;

	while (len > 0) {
		writeSize = M25PX80_PAGE_SIZE - (addr & (M25PX80_PAGE_SIZE - 1));
		if (writeSize > len)
			writeSize = len;
		writePage(addr, buf, writeSize);
		addr += writeSize;
		buf += writeSize;
		len -= writeSize;
	}
}

void SpiFlash::writePage(uint32_t addr, uint8_t *buf, unsigned int len)
{
	while (getStatus(*spi, cs) & M25PX80_REG_STATUS_WIP) {}
	enableWrite(*spi, cs);
	digitalWrite(cs, LOW);
	spi->transfer(M25PX80_PP);
	sendAddr(*spi, addr);
	for (int i = 0; i < len; i++)
		spi->transfer(buf[i]);
	digitalWrite(cs, HIGH);
}

void SpiFlash::write8(uint32_t addr, uint8_t value)
{
	while (getStatus(*spi, cs) & M25PX80_REG_STATUS_WIP) {}
	enableWrite(*spi, cs);
	digitalWrite(cs, LOW);
	spi->transfer(M25PX80_PP);
	sendAddr(*spi, addr);
	spi->transfer(value);
	digitalWrite(cs, HIGH);
}

void SpiFlash::erase(uint32_t addr)
{
	while (getStatus(*spi, cs) & M25PX80_REG_STATUS_WIP) {}
	enableWrite(*spi, cs);
	digitalWrite(cs, LOW);
	spi->transfer(M25PX80_SSE);
	sendAddr(*spi, addr);
	digitalWrite(cs, HIGH);
}
